function contarCaracteresYRepeticiones() {
  const frase = prompt("Ingrese una frase:");
  const cantidadCaracteres = frase.length;
  const fraseMinusculas = frase.toLowerCase();
  const repeticiones = {};
  for (let i = 0; i < fraseMinusculas.length; i++) {
    const caracter = fraseMinusculas[i];
    if (repeticiones[caracter]) {
      repeticiones[caracter]++;
    } else {
      repeticiones[caracter] = 1;
    }
  }

  console.log(`La frase tiene ${cantidadCaracteres} caracteres.`);
  console.log("Repeticiones de cada carácter:");
  for (const caracter in repeticiones) {
    console.log(`El carácter ${caracter} se repite ${repeticiones[caracter]} veces.`);
  }
}

contarCaracteresYRepeticiones();