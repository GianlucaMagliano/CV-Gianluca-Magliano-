
 let persona1 = {
    nombre: " Gianluca",
    edad:  " 21",
    ocupacion: " call center",
    intereses: [" jugar futbol, programar, dormir"] 

 };

 console.log("La persona se llama" + persona1.nombre, "es muy joven tiene" + persona1.edad, "se dedica a" + persona1.ocupacion, "y sus hobbies son"+ persona1.intereses)

let persona2 = {
    nombre: " Jose",
    edad: " 29",
    ocupacion: " arquitecto",
    intereses: [" leer y cocinar"]

 };
 console.log("La persona se llama" + persona2.nombre, "es muy joven tiene" + persona2.edad, "se dedica a" + persona2.ocupacion, "y sus hobbies son"+ persona2.intereses)

let persona3 = {
    nombre: " Hugo",
    edad: " 19",
    ocupacion: " cocinero",
    intereses: [" hacer crucigramas y salir de fiesta"]

 };

 console.log("La persona se llama" + persona3.nombre, "es muy joven tiene" + persona3.edad, "se dedica a" + persona3.ocupacion, "y sus hobbies son"+ persona3.intereses)



