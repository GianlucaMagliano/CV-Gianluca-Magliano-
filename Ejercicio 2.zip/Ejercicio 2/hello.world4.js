let preguntas = [
    {
        pregunta: "Cual es la capital de Italia?",
        respuestaCorrecta: "Roma"
    },
    {
        pregunta: "Cual es la capital de Venezuela?",
        respuestaCorrecta: "Caracas"
    },
    {
        pregunta: "Cual es la capital de Argentina?",
        respuestaCorrecta: "Buenos Aires"
    },
    {
        pregunta: "Cual es la capital de Brasil?",
        respuestaCorrecta: "Brasilia"
    },
    {
        pregunta: "Cual es la capital de Alemania?",
        respuestaCorrecta: "Berlin"
    },
];

let respuestasCorrectas = 0;

for (let i = 0; i < preguntas.length; i++) {
  let respuestaUsuario = prompt(preguntas[i].pregunta);
  if (respuestaUsuario.toLowerCase() === preguntas[i].respuestaCorrecta.toLowerCase()) {
    respuestasCorrectas++;
  }
}

alert(`Has acertado ${respuestasCorrectas} de las 5 preguntas.`);